import Image from 'next/image'
import Link from 'next/link'

export default function Home() {
  return (
    <div className="bg-black font-jura">
      <section className="min-h-[85vh] flex flex-col items-center justify-center px-8 pt-32 pb-24">
        <div className="w-full max-w-6xl flex flex-col lg:flex-row items-center justify-center">
          <div className="lg:w-1/2 text-center lg:text-left mb-8 lg:mb-0 lg:pr-16">
            <h1 className="text-white text-4xl md:text-5xl lg:text-6xl font-light leading-[1.2] mb-4">
              <a href="https://ritvik.io" target="_blank" rel="noopener noreferrer" className="hover:underline">
                rivar
              </a>
              <br />industries
            </h1>
            <p className="text-[rgba(207,207,207,0.80)] text-base md:text-lg lg:text-xl font-extralight leading-relaxed max-w-[600px]">
              the expiremental lab tinkering with frontier technology. built by <a href="https://ritvik.io" target="_blank" rel="noopener noreferrer" className="hover:underline">ritvik varghese</a>.
            </p>
          </div>
          <div className="lg:w-1/2 flex justify-center items-center lg:pl-16">
            <div className="w-full max-w-[600px] rounded-lg overflow-hidden">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/formerlyripen_Hayao_Miyazaki_cartoon_movies_style._A_futurist_51a0c8d8-72da-4ff0-a4c0-cf632622c1d7_3%20(1)-zAsjcMB7yDb3IkaBITENZHZGkzFF6n.png"
                alt="Rivar Industries Laboratory"
                width={600}
                height={600}
                className="rounded-lg w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>
      
      <section className="min-h-[85vh] flex flex-col items-center justify-center px-8 pt-24 pb-16">
        <div className="w-full max-w-6xl flex flex-col lg:flex-row items-center justify-center">
          <div className="lg:w-1/2 text-center lg:text-left mb-8 lg:mb-0 lg:pr-16">
            <h2 className="text-white text-4xl md:text-5xl lg:text-6xl font-light leading-[1.2] mb-6">
              weekly progress
            </h2>
            <div className="space-y-4">
              <Link href="https://ritvikvarghese.substack.com/" className="block text-[rgba(207,207,207,0.80)] text-base md:text-lg lg:text-xl font-extralight hover:underline">
                19th jan 2025: initiate labs
              </Link>
            </div>
          </div>
          <div className="lg:w-1/2 flex justify-center items-center lg:pl-16">
            <div className="w-full max-w-[600px] rounded-lg overflow-hidden">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/llllllllll7100_Futuristic_mecha_repair_shop_anime_style_mechani_64babfa5-ba21-42f0-8146-a6d929e96807-5oMPns4FRDMcd6pWDYvWVToknjvSgX.png"
                alt="Futuristic mecha repair shop"
                width={600}
                height={450}
                className="rounded-lg w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

